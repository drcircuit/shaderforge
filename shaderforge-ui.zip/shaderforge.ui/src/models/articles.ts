export interface Article {
  id: PropertyKey;
  title: string;
  url: string;
  isExternal: boolean;
}